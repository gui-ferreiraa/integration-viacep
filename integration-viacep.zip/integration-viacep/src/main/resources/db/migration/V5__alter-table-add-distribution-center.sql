ALTER TABLE product ADD COLUMN distribution_center TEXT;

UPDATE product SET distribution_center = 'Mogi das Cruzes'
WHERE id IN ('p1', 'p2', 'p3');

UPDATE product SET distribution_center = 'Suzano'
WHERE id IN ('p4', 'p5', 'p6', 'p10', 'p11', 'p12');

UPDATE product SET distribution_center = 'Poá'
WHERE id IN ('p7', 'p8', 'p9', 'p13', 'p14', 'p15');

UPDATE product SET distribution_center = 'São Paulo'
WHERE id IN ('p16', 'p17', 'p18', 'p19', 'p20');